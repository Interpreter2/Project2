package com.artgallery.dto;

import com.artgallery.model.Bid;
import com.artgallery.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

// BidRepository.java
public interface BidRepository extends JpaRepository<Bid, Long> {
    List<Bid> findByProduct(Product product);
}
