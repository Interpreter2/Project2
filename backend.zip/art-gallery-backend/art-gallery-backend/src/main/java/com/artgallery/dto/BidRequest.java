package com.artgallery.dto;

import java.math.BigDecimal;

public class BidRequest {
    private BigDecimal amount;

    // Getters and setters
    // You might want to add validation annotations based on your requirements
}
