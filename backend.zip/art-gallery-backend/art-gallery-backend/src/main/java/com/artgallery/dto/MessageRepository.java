package com.artgallery.dto;

import com.artgallery.model.Message;
import com.artgallery.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

// MessageRepository.java
public interface MessageRepository extends JpaRepository<Message, Long> {
    List<Message> findByProduct(Product product);
}
