package com.artgallery.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.artgallery.dao.ProductDao;
import com.artgallery.model.Product;
import com.artgallery.utility.StorageService;

import java.util.List;


@Service
public class ProductServiceImpl implements ProductService {
	
	@Autowired 
	private ProductDao productDao;
	
	@Autowired
	private StorageService storageService;

	@Override
	public void addProduct(Product product, MultipartFile productImmage) {
		
		String productImageName = storageService.store(productImmage);
		
		product.setImageName(productImageName);
		
		this.productDao.save(product);
	}

	@Override
	public List<Product> searchProducts(String query) {
		// You can customize this method based on your needs.
		// For simplicity, let's assume you want to search by product name or description.

		return productDao.findByTitleContainingIgnoreCaseOrDescriptionContainingIgnoreCase(query, query);
	}

}
