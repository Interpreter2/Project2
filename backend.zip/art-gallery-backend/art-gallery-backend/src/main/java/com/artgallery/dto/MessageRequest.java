package com.artgallery.dto;

public class MessageRequest {
    private String content;

    // Getters and setters
    // You might want to add validation annotations based on your requirements
}
