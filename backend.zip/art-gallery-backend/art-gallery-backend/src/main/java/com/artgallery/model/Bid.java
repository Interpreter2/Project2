package com.artgallery.model;

import javax.persistence.*;
import java.math.BigDecimal;

// Bid.java
@Entity
public class Bid {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "product_id")
    private Product product;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User bidder;

    private BigDecimal amount;

    // Getters and setters
}
