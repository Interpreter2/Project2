package com.artgallery.utility;

public class HeaderCode {

}
