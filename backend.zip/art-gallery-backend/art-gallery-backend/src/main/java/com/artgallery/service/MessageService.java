package com.artgallery.service;

import com.artgallery.dao.ProductDao;
import com.artgallery.dto.MessageRepository;
import com.artgallery.model.Message;
import com.artgallery.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

// MessageService.java
@Service
public class MessageService {

    @Autowired
    private MessageRepository messageRepository;

    @Autowired
    private ProductDao productRepository;

    public List<Message> getMessagesByProduct(Long productId) {
        return messageRepository.findByProduct(product);
    }

    // Add methods for sending messages, etc.
}
