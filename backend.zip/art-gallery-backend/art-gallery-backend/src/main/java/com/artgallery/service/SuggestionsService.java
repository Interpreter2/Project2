package com.artgallery.service;

import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;

// SuggestionsService.java
@Service
public class SuggestionsService {

    // Inject your repository or any other data source if needed

    public List<String> getSuggestions(String query) {
        // Implement logic to fetch relevant suggestions based on the input query
        // You can use JPA repositories, JDBC, or any other data source
        // For simplicity, returning dummy suggestions here
        return Arrays.asList("Suggestion1", "Suggestion2", "Suggestion3");
    }
}
