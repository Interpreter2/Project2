package com.artgallery.controller;

import com.artgallery.dto.BidRequest;
import com.artgallery.model.Bid;
import com.artgallery.model.Product;
import com.artgallery.service.BidService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/bids")
public class BidController {

    @Autowired
    private BidService bidService;

    @GetMapping("/getBids")
    public ResponseEntity<List<Bid>> getBidsByProduct(@RequestParam Product productId) {
        List<Bid> bids = bidService.getBidsByProduct(productId);
        return new ResponseEntity<>(bids, HttpStatus.OK);
    }

    @PostMapping("/placeBid")
    public ResponseEntity<Void> placeBid(@RequestParam Long productId, @RequestBody BidRequest bidRequest) {
        bidService.placeBid(productId, bidRequest);
        return new ResponseEntity<>(HttpStatus.CREATED);
    }

    // Other endpoints...
}
