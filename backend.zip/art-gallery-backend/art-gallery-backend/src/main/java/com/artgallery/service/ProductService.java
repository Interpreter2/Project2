package com.artgallery.service;

import org.springframework.web.multipart.MultipartFile;

import com.artgallery.model.Product;

import java.util.List;

public interface ProductService {
	
	void addProduct(Product product, MultipartFile productImmage);

	List<Product> searchProducts(String query);
}
