package com.artgallery.controller;

import com.artgallery.service.SuggestionsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

// SuggestionsController.java
@RestController
@RequestMapping("/api")
public class SuggestionsController {

    @Autowired
    private SuggestionsService suggestionsService;

    @GetMapping("/suggestions")
    public ResponseEntity<List<String>> getSuggestions(@RequestParam String q) {
        List<String> suggestions = suggestionsService.getSuggestions(q);
        return ResponseEntity.ok(suggestions);
    }
}
